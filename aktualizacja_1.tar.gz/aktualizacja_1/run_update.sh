#!/bin/bash

# Przykładowa aktualizacja zmieniająca tapetę
cp "$(dirname "$0")/tapeta.jpg" /home/user/Obrazy/tapeta.jpg
DISPLAY=:0 feh --bg-scale /home/user/Obrazy/tapeta.jpg
echo "Zmieniono tapetę"
